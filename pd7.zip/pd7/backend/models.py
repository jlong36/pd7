from django.db import models
from django.db.models.fields import BooleanField
from django.utils import timezone

class Users(models.Model):
    firstName = models.CharField(max_length=15)
    lastName = models.CharField(max_length=15)
    middleName = models.CharField(max_length=15)
    jobTitle = models.CharField(max_length=15)
    email = models.EmailField(max_length=30)
    phone = models.CharField(max_length=15)
    cellPhone = models.CharField(max_length=15)

    def __str__(self):
        return (self.lastName + ', ' + self.firstName)

class Client(models.Model):
    clientName = models.CharField(max_length=15)
    clientType = models.CharField(max_length=15)

    def __str__(self):
        return self.clentName

class Location(models.Model):
    address = models.CharField(max_length=20)
    city = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    zipCode = models.CharField(max_length=10)
    country = models.CharField(max_length=20)
    phoneNumber = models.CharField(max_length=20)
    faxNumber = models.CharField(max_length=20)
    clientID = models.ForeignKey(Client, on_delete=models.CASCADE)

    def __str__(self):
        return self.clientID

class TestStandard(models.Model):
    standardName = models.CharField(max_length=15)
    description = models.TextField()
    publishedDate = models.DateTimeField(default=timezone.now) 

    def __str__(self):
        return self.standardName

class TestSequence(models.Model):
    sequenceName = models.CharField(max_length=15)

    def __str__(self):
        return self.sequenceName

class Product(models.Model):
    modelNumber = models.CharField(max_length=15)
    productName = models.CharField(max_length=15)
    cellTechnology = models.CharField(max_length=15)
    cellManufacturer = models.CharField(max_length=15)
    numberOfCells = models.CharField(max_length=15)
    numberOfCellsInSeries = models.CharField(max_length=15)
    numberOfSeriesStrings = models.CharField(max_length=15)
    numberOfDiodes = models.CharField(max_length=15)
    productLength = models.CharField(max_length=15)
    productWidth = models.CharField(max_length=15)
    productWeight = models.CharField(max_length=15)
    superstateType = models.CharField(max_length=15)
    seperstateManufacturer = models.CharField(max_length=15)
    substrateType = models.CharField(max_length=15)
    substrateManufacturer = models.CharField(max_length=15)
    frameType = models.CharField(max_length=15)
    frameAdhesive = models.CharField(max_length=15)
    encapsulateType = models.CharField(max_length=15)
    encapsulateManufacturer = models.CharField(max_length=15)
    junctionnBoxType = models.CharField(max_length=15)
    junctionnBoxManufacturer = models.CharField(max_length=15)

    def __str__(self):
        return self.productName

class PerformanceData(models.Model):

    modelNumber = models.ForeignKey(Product, on_delete=models.CASCADE)
    sequencID = models.ForeignKey(TestSequence, on_delete=models.CASCADE)
    maxSystemVoltage = models.CharField(max_length=15)
    voc = models.CharField(max_length=15)
    isc = models.CharField(max_length=15)
    vmp = models.CharField(max_length=15)
    imp = models.CharField(max_length=15)
    pmp = models.CharField(max_length=15)
    ff = models.CharField(max_length=15)

class Service(models.Model):
    serviceName = models.CharField(max_length=15)
    description = models.TextField
    isFlRequired = BooleanField()
    FlFrequency =  models.CharField(max_length=15)
    standardID = models.ForeignKey(TestStandard, on_delete=models.CASCADE)

class Certificate(models.Model):
    certificateNumber = models.CharField(max_length=15)
    userID = models.ForeignKey(Users, on_delete=models.CASCADE)
    standardID = models.ForeignKey(TestStandard, on_delete=models.CASCADE)
    locationID = models.ForeignKey(Location, on_delete=models.CASCADE)
    modelNumber = models.ForeignKey(Product, on_delete=models.CASCADE )





